﻿namespace GdalPoc.Models
{
    internal class Coordinate
    {
        public double latitude { get; set; }

        public double longitude { get; set; }
    }
}