﻿using Newtonsoft.Json;
using System.ComponentModel;

namespace GdalPoc.Models
{
    public class OrthoCoverageChildAOIProperty
    {
        [JsonProperty("Name")]
        public string Name { get; set; }

        [JsonProperty("Coverage Type")]
        public string CoverageType { get; set; }

        [JsonProperty("Min GSD")]
        public decimal MinGSD { get; set; }

        [JsonProperty("Max GSD")]
        public decimal MaxGSD { get; set; }

        [JsonProperty("Min Date")]
        public string MinDate { get; set; }

        [JsonProperty("Max Date")]
        public string MaxDate { get; set; }

        [JsonProperty("Camera Technology")]
        public string CameraTechnology { get; set; }
    }
}