﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;

namespace GdalPoc.Models
{
    public class TileImage
    {
        public int xIndx { get; internal set; }
        public int yindx { get; internal set; }
        public string URL { get; internal set; }
        public string requestID { get; internal set; }
        public Image imgTile { get; internal set; }
    }
}