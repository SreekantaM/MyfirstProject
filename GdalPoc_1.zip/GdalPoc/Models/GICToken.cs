﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GdalPoc.Models
{
    public class GICToken
    {
        public string token { get; set; }
        public string expiration_date { get; set; }
    }
}