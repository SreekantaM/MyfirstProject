﻿using Newtonsoft.Json;

namespace GdalPoc.Models
{
    public class OrthoCoverageFeatureProperty
    {
        [JsonProperty("AOI")]
        public string AOI { get; set; }

        [JsonProperty("Coverage Type")]
        public string CoverageType { get; set; }

        [JsonProperty("Min GSD")]
        public decimal MinGSD { get; set; }

        [JsonProperty("Max GSD")]
        public decimal MaxGSD { get; set; }

        [JsonProperty("Min Capture date")]
        public string MinCaptureDate { get; set; }

        [JsonProperty("Max Capture date")]
        public string MaxCaptureDate { get; set; }

        [JsonProperty("layer")]
        public string Layer { get; set; }

        [JsonProperty("AOI Area")]
        public decimal AOIArea { get; set; }
    }
}