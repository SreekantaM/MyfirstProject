﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace GdalPoc.Models
{
    public class OrthoCoverageFeature
    {
        [JsonProperty("type")]
        public string FeatureType { get; set; }

        [JsonProperty("properties")]
        public OrthoCoverageFeatureProperty Properties { get; set; }

        [JsonProperty("geometry")]
        public string Geometry { get; set; }

        [JsonProperty("Child AOI")]
        public List<OrthoCoverageChildAOIProperty> ChildAOI { get; set; }
    }
}