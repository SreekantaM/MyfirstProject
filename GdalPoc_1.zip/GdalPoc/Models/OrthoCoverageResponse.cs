﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GdalPoc.Models
{
    public class OrthoCoverageResponse
    {
        [JsonProperty("type")]
        public string ResponseType { get; set; }

        [JsonProperty("features")]
        public List<OrthoCoverageFeature> Features { get; set; }

        [JsonProperty("area")]
        public decimal Area { get; set; }

        [JsonProperty("epsg")]
        public int EPSG { get; set; }
    }
}