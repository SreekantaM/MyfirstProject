﻿using GdalPoc.Models;
using Newtonsoft.Json;
using OSGeo.OGR;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace GdalPoc.Controllers
{
    [RoutePrefix("services/gdal")]
    public class HomeController : ApiController
    {
        [Route("read")]
        [HttpGet]
        public void ReadJson()
        {
            try
            {

                string token = GetToken();
                if (!string.IsNullOrEmpty(token))
                {
                    string dataDirectoryPath = HttpContext.Current.Server.MapPath("~/App_Data");
                    if (Directory.Exists(dataDirectoryPath))
                    {
                        DirectoryInfo directoryInfo = Directory.CreateDirectory(dataDirectoryPath);
                        FileInfo[] fileInfos = directoryInfo.GetFiles("*.geojson", SearchOption.TopDirectoryOnly);

                        foreach (FileInfo fileInfo in fileInfos)
                        {
                            string fileName = fileInfo.Name.Split('.')[0].ToUpper();
                            string filePath = fileInfo.FullName;
                            string geomWKT = ReadGeoJson(filePath, out Envelope envelope);
                            if (!string.IsNullOrEmpty(geomWKT))
                            {
                                List<string> layerNames = new List<string>();
                                try
                                {
                                    string coverageResponse = CheckOrthoCoverage(token, geomWKT);
                                    if (!string.IsNullOrEmpty(coverageResponse))
                                    {
                                        OrthoCoverageResponse coverageResponseObj = JsonConvert.DeserializeObject<OrthoCoverageResponse>(coverageResponse);
                                        if (coverageResponseObj.Features.Count > 0)
                                        {
                                            foreach (OrthoCoverageFeature orthoCoverageFeature in coverageResponseObj.Features)
                                            {
                                                if (orthoCoverageFeature.Properties.CoverageType == "ortho" || orthoCoverageFeature.Properties.CoverageType == "quick-ortho")
                                                {
                                                    if (!layerNames.Contains(orthoCoverageFeature.Properties.Layer))
                                                        layerNames.Add(orthoCoverageFeature.Properties.Layer);
                                                }
                                            }
                                        }
                                    }
                                }
                                catch(Exception innerEx)
                                {
                                    continue;
                                }
                                string layerName = "";

                                if (layerNames.Contains("bluesky-ultra-g"))
                                    layerName = "bluesky-ultra-g";
                                else if (layerNames.Contains("bluesky-ultra"))
                                    layerName = "bluesky-ultra";
                                else if (layerNames.Contains("bluesky-high"))
                                    layerName = "bluesky-high";
                                else if (layerNames.Contains("graysky-g"))
                                    layerName = "graysky-g";
                                else if (layerNames.Contains("graysky"))
                                    layerName = "graysky";

                                if (!string.IsNullOrEmpty(layerName))
                                {
                                    int zoom = 19;
                                    //Calculate the pixel dimension bounding box
                                    TileSystem.LatLongToPixelXY(envelope.MinY, envelope.MinX, zoom, out int minPixelX, out int maxPixelY);
                                    //Calculate the pixel dimension bounding box
                                    TileSystem.LatLongToPixelXY(envelope.MaxY, envelope.MaxX, zoom, out int maxPixelX, out int minPixelY);

                                    TileSystem.PixelXYToTileXY(minPixelX, minPixelY, out int minTileX, out int minTileY);
                                    TileSystem.PixelXYToTileXY(maxPixelX, maxPixelY, out int maxTileX, out int maxTileY);
                                    try
                                    {
                                        Image imgUncropped = MosaicTiles(minTileX, maxTileX - minTileX + 1, minTileY, maxTileY - minTileY + 1, zoom, token, layerName, "");
                                        using (var m = new MemoryStream())


                                        {
                                            imgUncropped.Save(m, System.Drawing.Imaging.ImageFormat.Png);
                                            var img = Image.FromStream(m);
                                            img.Save(string.Format("{0}\\{1}_{2}.png", dataDirectoryPath, fileName, zoom));
                                        }
                                    }
					//GeoReferance 
					



                                    catch(Exception innerEx2)
                                    {
                                        continue;
                                    }
                                }

                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        TileImage[] tileImages;
        public int tileSizeInPixels = 256;

        private string ReadGeoJson(string filePath, out Envelope envelope)
        {
            string ogrDriverName = GetOgrDriverName(filePath);
            Driver driver = Ogr.GetDriverByName(ogrDriverName);

            DataSource dataSource = driver.Open(filePath, 0);
            Layer layer = dataSource.GetLayerByIndex(0);
            envelope = new Envelope();

            string geomWKT = string.Empty;
            Geometry geometry = null;

            Feature feature = layer.GetNextFeature();
            while (feature != null)
            {
                if (feature.GetGeometryRef() != null)
                {
                    if (geometry == null)
                        geometry = feature.GetGeometryRef();
                    else
                    {
                        geometry = geometry.Union(feature.GetGeometryRef());
                    }
                }
                feature = layer.GetNextFeature();
            }
            if (geometry != null)
            {
                geometry.GetEnvelope(envelope);
                
                Geometry ring = new Geometry(wkbGeometryType.wkbLinearRing);
                ring.AddPoint_2D(envelope.MinX, envelope.MinY);
                ring.AddPoint_2D(envelope.MaxX, envelope.MinY);
                ring.AddPoint_2D(envelope.MaxX, envelope.MaxY);
                ring.AddPoint_2D(envelope.MinX, envelope.MaxY);
                ring.AddPoint_2D(envelope.MinX, envelope.MinY);

                Geometry polygon_env = new Geometry(wkbGeometryType.wkbPolygon);
                polygon_env.AddGeometry(ring);

                polygon_env.ExportToWkt(out geomWKT);
            }

            return geomWKT;
        }

        //this function requests the needed tiles from vexcels tile services. for efficiency, each tile
        //is requested on a separate thread to gather all the tiles in parrallel 
        private Image MosaicTiles(int originXtile, int numXtiles, int originYtile,
            int numYtiles, int originZtile, string VexcelToken, string layerName, string AOIname)
        {
            //Create a Bitmap for the RGB tiles
            var bmp = new System.Drawing.Bitmap(tileSizeInPixels * numXtiles, tileSizeInPixels * numYtiles);
            var g = Graphics.FromImage(bmp);

            //we'll need a task per tile
            int numerOftiles = numYtiles * numXtiles;
            Task[] tasks = new Task[numerOftiles];

            tileImages = new TileImage[numerOftiles];
            int tileCnt = -1;
            int colIndx = 0;
            int rowIndx = 0;

            //First, loop through each desired tile and create a TileImage object to be filled asynchronously
            for (int row = originYtile; row < originYtile + numYtiles; row++)
            {
                colIndx = 0;
                for (int col = originXtile; col < originXtile + numXtiles; col++)
                {
                    tileCnt++;
                    TileImage thisTileImage = new TileImage();
                    thisTileImage.xIndx = colIndx;
                    thisTileImage.yindx = rowIndx;
                    thisTileImage.URL = "https://api.gic.org/images/GetOrthoImageTile/" + layerName + "/" + originZtile + "/" +
                           col + "/" + row + "/true?format=image%2Fpng&token=" + VexcelToken;
                    if (AOIname != "")
                        thisTileImage.URL += "&AOI=" + AOIname;
                    thisTileImage.requestID = "t" + tileCnt;

                    tileImages[tileCnt] = thisTileImage;
                    colIndx++;
                }
                rowIndx++;
            }

            //Now go fetch eeach tile asynchronously
            tileCnt = 0;
            DateTime startTime = DateTime.Now;
            foreach (TileImage thisTI in tileImages)
            {
                tasks[tileCnt] = Task.Run(() =>
                {
                    FetchTile(thisTI);
                    int tileindx = tileCnt;
                });
                tileCnt++;
            }

            //wait here for all threads to complete.
            Task.WaitAll(tasks);

            //loop again to stitch the tiles together into a single bitmap
            colIndx = 0;
            rowIndx = 0;
            tileCnt = -1;
            for (int row = originYtile; row < originYtile + numYtiles; row++)
            {
                colIndx = 0;
                for (int col = originXtile; col < originXtile + numXtiles; col++)
                {
                    tileCnt++;
                    g.DrawImage(tileImages[tileCnt].imgTile, tileSizeInPixels * colIndx, tileSizeInPixels * rowIndx);

                    colIndx++;
                }
                rowIndx++;
            }

            Image imageRGB = bmp;
            return imageRGB;
        }

        private TileImage FetchTile(TileImage tileImage)
        {
            if (tileImage.URL == null || tileImage.URL == "")
            {
                tileImage.imgTile = null;
            }
            else
            {
                using (WebClient webClient = new WebClient())
                {
                    DateTime startTime = DateTime.Now;
                    try
                    {
                        byte[] data = webClient.DownloadData(tileImage.URL);
                        MemoryStream memstream = new MemoryStream(data);
                        tileImage.imgTile =  Bitmap.FromStream(memstream);
                    }
                    catch (Exception ex)
                    {
                        tileImage.imgTile =  null;
                    }
                }
            }
            return tileImage;
        }

        private string GetToken()
        {
            string formData = "username=";
            string uri = "https://api.gic.org/auth/Login/";
            string token = string.Empty;

            HttpWebRequest httpWebRequest = CreateHttpRequest(uri, formData, "POST");
            WebResponse webResponse = httpWebRequest.GetResponse();
            using (Stream byteStream = webResponse.GetResponseStream())
            {
                using (StreamReader sr = new StreamReader(byteStream))
                {
                    string strResponse = sr.ReadToEnd();
                    GICToken tokenObj = JsonConvert.DeserializeObject<GICToken>(strResponse);
                    if (tokenObj != null)
                        token = tokenObj.token;
                }
            }
            return token;
        }

        private string CheckOrthoCoverage(string token, string geomWKT)
        {
            string data = "token=" + token + "&format=wkt&wkt=" + geomWKT;
            string url = "https://api.gic.org/metadata/OrthoCoverage?" + data;
            string coverageResponse = "";

            HttpWebRequest httpWebRequest = CreateHttpRequest(url, "", "GET");
            WebResponse webResponse = httpWebRequest.GetResponse();
            using (Stream byteStream = webResponse.GetResponseStream())
            {
                using (StreamReader sr = new StreamReader(byteStream))
                {
                    coverageResponse = sr.ReadToEnd();
                }
            }
            return coverageResponse;
        }

        private HttpWebRequest CreateHttpRequest(string uri, string postData, string method)
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate { return true; });
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                        | SecurityProtocolType.Tls11
                        | SecurityProtocolType.Tls12
                        | SecurityProtocolType.Ssl3;

            HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(uri);
            req.ServicePoint.Expect100Continue = false;
            req.Proxy = HttpWebRequest.DefaultWebProxy;
            req.Method = method;

            if (method == "POST")
            {
                req.ContentType = "application/x-www-form-urlencoded";
                byte[] bytes = Encoding.UTF8.GetBytes(postData);
                req.ContentLength = bytes.Length;
                using (Stream outputStream = req.GetRequestStream())
                {
                    outputStream.Write(bytes, 0, bytes.Length);
                }
            }

            return req;
        }

        private string GetOgrDriverName(string filePath)
        {
            string ogrDriverName = string.Empty;
            string fileExtension = filePath.Substring(filePath.LastIndexOf('.') + 1);

            switch (fileExtension.ToUpper())
            {
                case "SHP":
                    ogrDriverName = "ESRI Shapefile";
                    break;
                case "XLSX":
                    ogrDriverName = "XLSX";
                    break;
                case "GEOJSON":
                    ogrDriverName = "GeoJSON";
                    break;
            }

            return ogrDriverName;
        }
    }
}
